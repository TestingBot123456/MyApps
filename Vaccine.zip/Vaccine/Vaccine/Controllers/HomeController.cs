using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Vaccine.Models;
using Vaccine.Services;

namespace Vaccine.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly APIClient _client;
        public HomeController(ILogger<HomeController> logger, APIClient aPIClient)
        {
            _logger = logger;
            _client = aPIClient;
        }

        public IActionResult Index()
        {
            return View();
        }
        public async Task<IActionResult> FillPatient(int PatientID)
        {
            Fill_Vaccine fill_Vaccine = new Fill_Vaccine();
            fill_Vaccine.NationalityList = await _client.LoadNationalityListAsync();
            fill_Vaccine.VaccineList = await _client.LoadVaccineListAsync();
            if (PatientID > 0)
            {
                var patient = new PatientDTO();
                patient.PatientId = PatientID;
                var Patient = (await _client.SearchPatientAsync(patient)).FirstOrDefault();
                if (Patient != null)
                {
                    fill_Vaccine.PatientID = Patient.PatientId;
                    fill_Vaccine.PatientName = Patient.PatientName;
                    fill_Vaccine.NationalityID = Patient.NationalityID;
                    fill_Vaccine.DOB = Patient.DOB;
                    fill_Vaccine.EmiratesID = Patient.EmiratesID;
                    fill_Vaccine.PassportNo = Patient.PassportNo;
                }
            }
            return PartialView("_PartialPatientDetails", fill_Vaccine);
        }
        public async Task<IActionResult> LoadPatients()
        {
            var patients = await _client.LoadPatientsViewAsync();
            return PartialView("_PartialPatientList", patients);
        }
    }
}
