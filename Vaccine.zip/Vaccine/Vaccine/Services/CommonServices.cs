﻿namespace Vaccine.Services
{
    public class CommonServices:IcommonServices
    {
    }
}
