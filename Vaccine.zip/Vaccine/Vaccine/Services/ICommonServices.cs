﻿namespace Vaccine.Services
{
    public interface IcommonServices
    {
    }
}
