﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Vaccine_API.Data;

namespace Vaccine_API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class VaccineController : ControllerBase
    {
        private readonly APPDBContext _db;

        // Constructor to inject the ApplicationDbContext
        public VaccineController(APPDBContext db)
        {
            _db = db; // Assign the injected DbContext to _db
        }
        [HttpGet(Name = "GetPatients")]

        public ActionResult GetPatients()
        {
            var patients = _db.PatientMaster.ToList();
            return Ok(patients);
        }
    }
}
