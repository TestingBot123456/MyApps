﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Vaccine_API.Models;
namespace Vaccine_API.Data
{
    public class APPDBContext : DbContext
    {
        public APPDBContext(DbContextOptions<APPDBContext> options)
            : base(options)
        {
        }

        public DbSet<Patient> PatientMaster { get; set; }
    }

}
