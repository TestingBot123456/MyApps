﻿using System.ComponentModel.DataAnnotations;

namespace Vaccine_API.Models
{
    public class VaccinationRecord
    {
        [Key]
        public int OrderID { get; set; } // Auto-incremented ID for each vaccination record
        public int PatientID { get; set; } // Foreign key to Patient table
        public int VaccineID { get; set; } // Foreign key to Vaccine_Master table
        public DateTime VaccinationDate { get; set; } // Date of vaccination
        public int DoseNumber { get; set; } // Dose number (1st, 2nd, etc.)
        public string? AddedBy { get; set; } // Person who added the record
        public DateTime? AddedDate { get; set; } // Date when the record was added (nullable)
        public string? Notes { get; set; } // Additional notes (optional)
        public bool? Suspended { get; set; } // Indicates if the record is suspended (nullable)
    }
}
